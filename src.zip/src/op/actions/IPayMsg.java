package op.actions;

public interface IPayMsg {

    void PayMsg();

}
