package op.actions;

public interface IEnterPinMsg {

    void EnterPinMsg();

}
