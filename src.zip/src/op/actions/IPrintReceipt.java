package op.actions;

import data.IDataStore;

public interface IPrintReceipt {

    void PrintReceipt(IDataStore iDataStore);

}
