package op.actions;

public class DisplayMenu2 implements IDisplayMenu {

    @Override
    public void DisplayMenu() {
        System.out.println("Select either Regular, Premium or Super fuel");
    }
}
