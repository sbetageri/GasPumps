package op.actions;

import data.IDataStore;

public interface IReturnCash {

    void ReturnCash(IDataStore iDataStore);

}
