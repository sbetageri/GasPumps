package op.actions;

import data.DataStore1;
import data.IDataStore;

public interface IInitializeData {

    void InitializeData(IDataStore dataStore);

}
