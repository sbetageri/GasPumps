package op.actions;

import data.IDataStore;

public interface ISetInitialValues {

    void SetInitialValues(IDataStore iDataStore);

}
