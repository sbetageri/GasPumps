package op.actions;

public interface IReadyMsg {

    void ReadyMsg();

}
