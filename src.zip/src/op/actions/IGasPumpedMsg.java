package op.actions;

import data.IDataStore;

public interface IGasPumpedMsg {

    void GasPumpedMsg(IDataStore iDataStore);

}
