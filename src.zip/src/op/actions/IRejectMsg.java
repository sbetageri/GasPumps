package op.actions;

public interface IRejectMsg {

    void RejectMsg();

}
