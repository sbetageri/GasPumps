package op.actions;

public class StopPump1 implements IStopPump{

    @Override
    public void StopPump() {

    }
}
