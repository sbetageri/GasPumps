package op.actions;

import data.IDataStore;

public class StorePin2 implements IStorePin {

    @Override
    public void StorePin(IDataStore iDataStore) {

    }
}
