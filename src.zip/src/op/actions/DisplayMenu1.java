package op.actions;

public class DisplayMenu1 implements IDisplayMenu {

    @Override
    public void DisplayMenu() {
        System.out.println("Select either Diesel or Regular fuel");
    }
}
