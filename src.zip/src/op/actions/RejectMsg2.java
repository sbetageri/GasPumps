package op.actions;

public class RejectMsg2 implements IRejectMsg {

    @Override
    public void RejectMsg() {
        System.out.println("Card Rejected");
    }
}
