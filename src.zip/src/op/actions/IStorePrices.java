package op.actions;

import data.IDataStore;

public interface IStorePrices {

    void StorePrices(IDataStore dataStore);

}
