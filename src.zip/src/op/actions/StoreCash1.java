package op.actions;

import data.IDataStore;

public class StoreCash1 implements IStoreCash {

    @Override
    public void StoreCash(IDataStore iDataStore) {
    }
}
