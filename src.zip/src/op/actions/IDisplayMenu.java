package op.actions;

public interface IDisplayMenu {

    void DisplayMenu();

}
