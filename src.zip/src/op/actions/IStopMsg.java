package op.actions;

public interface IStopMsg {

    void StopMsg();

}
