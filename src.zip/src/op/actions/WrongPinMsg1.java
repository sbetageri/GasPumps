package op.actions;

public class WrongPinMsg1 implements IWrongPinMsg {

    @Override
    public void WrongPinMsg() {
        System.out.println("Incorrect pin");
    }
}
