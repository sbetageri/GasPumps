package op.actions;

import data.IDataStore;

public interface IStoreCash {

    void StoreCash(IDataStore iDataStore);

}
