package op.actions;

import data.IDataStore;

public interface IPumpGasUnit {

    void PumpGasUnit(IDataStore iDataStore);

}
