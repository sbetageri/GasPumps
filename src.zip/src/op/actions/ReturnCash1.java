package op.actions;

import data.IDataStore;

public class ReturnCash1 implements IReturnCash {

    @Override
    public void ReturnCash(IDataStore iDataStore) {

    }
}
