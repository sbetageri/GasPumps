package op.actions;

public interface IStopPump {

    public void StopPump();

}
