package op.actions;

import data.IDataStore;

public interface IStorePin {

    void StorePin(IDataStore dataStore);

}
