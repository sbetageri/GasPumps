package op.actions;

public class StopMsg2 implements IStopMsg {

    @Override
    public void StopMsg() {
        System.out.println("Fuel pumping stopped");
    }
}
