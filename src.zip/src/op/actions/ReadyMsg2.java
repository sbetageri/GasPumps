package op.actions;

public class ReadyMsg2 implements IReadyMsg {

    @Override
    public void ReadyMsg() {
        System.out.println("Ready to start pumping");
    }
}
