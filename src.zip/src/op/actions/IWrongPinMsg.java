package op.actions;

public interface IWrongPinMsg {

    void WrongPinMsg();

}
