package op.actions;

public interface ICancelMsg {

    void CancelMsg();

}
