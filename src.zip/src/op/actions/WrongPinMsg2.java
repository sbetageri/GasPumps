package op.actions;

public class WrongPinMsg2 implements IWrongPinMsg {

    @Override
    public void WrongPinMsg() {

    }
}
