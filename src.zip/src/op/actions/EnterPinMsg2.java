package op.actions;

public class EnterPinMsg2 implements IEnterPinMsg {

    @Override
    public void EnterPinMsg() {

    }
}
