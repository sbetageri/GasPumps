package op.actions;

public class StopMsg1 implements IStopMsg {

    @Override
    public void StopMsg() {
        System.out.println("Fuel pumping stopped");
    }
}
