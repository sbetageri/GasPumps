package op.actions;

public class PayMsg1 implements IPayMsg {

    @Override
    public void PayMsg() {
        System.out.println("Pay by either Debit Card or Credit Card");
    }
}
