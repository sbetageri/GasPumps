package op.actions;

import data.IDataStore;

public interface ISetPrice {

    void setDataStore(IDataStore iDataStore);

    void SetPrice(int g, int m);

}
