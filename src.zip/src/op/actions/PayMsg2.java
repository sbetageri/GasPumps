package op.actions;

public class PayMsg2 implements IPayMsg {

    @Override
    public void PayMsg() {
        System.out.println("Pay by either Cash or Credit Card");
    }
}
