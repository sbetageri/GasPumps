package op.actions;

public class EnterPinMsg1 implements IEnterPinMsg {

    @Override
    public void EnterPinMsg() {
        System.out.println("Enter pin for debit card");
    }
}
