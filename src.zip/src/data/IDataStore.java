package data;

public abstract class IDataStore {
}
